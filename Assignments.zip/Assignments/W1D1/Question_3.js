
// 3. Implement an arrow function with feature below:
// concat('hi', [1, 2, 3], ['Hello', 'world']) -> return result: ['h', 'i', 1, 2, 3, 'Hello', 'world'];

const concat = (arr_1, arr_2, arr_) => {

  return [...arr_1, ...arr_2, ...arr_3];
  //return [...arg]

};

const result = concat('hi', [1, 2, 3], ['Hello', 'worldsssss']);
console.log(result)

