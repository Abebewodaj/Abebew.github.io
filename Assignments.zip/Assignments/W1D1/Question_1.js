/* 1.Create a function using function declaration named sum with one parameter of Array type, the
returned result is the sum of all elements which are greater than 20.;*/

function sum(arr) {
  let sum = 0;

  const result_Sum = arr.filter((item) => item > 20)
    .reduce(((accum, current) => accum + current), 0);
  return result_Sum;



    // or
// for (const elements of arr) {
//   if (elements > 20) {
//     sum += elements;
//   }
// }

//return sum;
}

const test_array = [10, 15, 25, 25, 12, 30, 60, 21];
console.log(sum(test_array));