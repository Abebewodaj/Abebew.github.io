
// 2. Create a function using function expression named getNewArray with one parameter of String Array
// , return a new array which contains all string, length is greater than and equal to 5, and
// contains letter ‘a’.

const getNewArray = function (str_arr) {
  
  /*const new_array = [];
  for (const str of str_arr) {
    if (str.length >= 5 && str.includes('a')) {
      new_array.push(str);
    }
  } */      
                       // or
  const new_array = str_arr.filter(str=> str.length >= 5 && str.includes('a'));

  return new_array;

};
const str_arr = ['testarray', 'byea', 'hello abebe'];
const result = getNewArray(str_arr);
console.log(result);

